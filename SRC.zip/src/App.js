import React from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Experience from './Pages/Experience';
import Home from './Pages/Home';
import Projects from './Pages/Projects';
import Navbar from './Component/Navbar';
import Footer from './Component/Footer';
import ProjectDisplay from './Pages/ProjectDisplay';
import Contacts from './Pages/Contacts';

const App = () => {

  return (
    <div className="App">
      <Router >
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/project" element={<Projects />} />
          <Route path="/project/:id" element={<ProjectDisplay />} />
          <Route path="/experience" element={<Experience />} />
          <Route path="/contacts" element={<Contacts />} />
        </Routes>
        <Footer/>
      </Router>
    </div>
  )
}

export default App