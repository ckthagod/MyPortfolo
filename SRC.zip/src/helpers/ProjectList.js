import Proj1 from "../assets/proj1.jpg";
import Proj2 from "../assets/proj2.jpg";
import Proj3 from "../assets/proj3.jpg";
import Proj4 from "../assets/proj4.jpg";
import Proj5 from "../assets/proj5.jpg";
import Proj6 from "../assets/proj6.jpg";

export const ProjectList = [
  {
    name: "Calculator Web App",
    image: Proj1,
    skills: "JavaScript,HTML,CSS,Math.js",
  },
  {
    name: "Form Web App",
    image: Proj2,
    skills: "React,Node.js,MongoDB",
  },
  {
    name: "Chatbot App",
    image: Proj3,
    skills: "React,Python,MongoDB",
  },
  {
    name: "To-Do App",
    image: Proj4,
    skills: "React,C#,MySQL,EntityFramework",
  },
  {
    name: "Online Timer App ",
    image: Proj5,
    skills: "React,EasyTimer.js,HTML,CSS",
  },
  {
    name: "Online File Manager",
    image: Proj6,
    skills: "ReactJS,HTML,CSS",
  },
];