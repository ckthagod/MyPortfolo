import React, { useRef } from 'react'
import emailjs from '@emailjs/browser';
import "../styles/Contacts.css"
const Contacts = () => {
    const form = useRef();
    async function Submit(e) {
        e.preventDefault();

        await emailjs.sendForm("service_ciepkvx", "template_xmfo9v2", form.current, "frWCgAjIK-7-vmiJ_")
            .then((res) => {
                console.log(res.text);
                alert("CONTACTS SENT");
                e.target.reset();
            }, (err) => {
                console.log(err.text);
                alert("Error Ocurred, Sorry");
            })
    }
    return (
        <div className="Contacts">

            <form ref={form} onSubmit={Submit} className="Card">
                <label >Contact Me Here</label>
                <input type="text" placeholder='Name' name="name" required />
                <input type="email" placeholder='Email' required name="user_email" />
                <textarea className='area' name="message" placeholder='Messeges' />
                <button>Submit</button>
            </form>
        </div>
    )
}

export default Contacts