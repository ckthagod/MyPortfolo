import React from "react";
import LocationOnIcon from '@mui/icons-material/LocationOn';

import "../styles/Home.css";

function Home() {
  return (
    <div className="home">
      <div className="about">
        <h2> Welcome To My Portfolio</h2>
        <div className="prompt">
          <p>A hardworking web developer with knowledge and fascination in all things
            Software.</p>
          <LocationOnIcon />
          <h1>Gauteng , Pretoria </h1>
        </div>
      </div>
      <div className="skills">
        <h1> Skills</h1>
        <ol className="list">
          <li className="item">
            <h2> Front-End</h2>
            <span>
              ReactJS, VueJS, Flutter , HTML, CSS , Android Studio.
            </span>
          </li>
          <li className="item">
            <h2>Back-End</h2>
            <span>
              ASP.NET CORE , ExpressJS , FLASK , FastAPI , MongoDB , SQL Server.
            </span>
          </li>
          <li className="item">
            <h2>Languages</h2>
            <span>JavaScript, Kotlin , C# , C++ ,Dart, Java , Python.</span>
          </li>
        </ol>
      </div>
    </div>
  );
}

export default Home;
